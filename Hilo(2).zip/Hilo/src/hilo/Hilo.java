/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import com.rabbitmq.client.*;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.*;
import redis.clients.jedis.Jedis;
import java.security.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jose
 */
public class Hilo {

    /**
     * @param args the command line arguments
     */
    private final static String QUEUE_NAME = "login";

    public static void main(String[] args) throws Exception {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("35.237.249.51");
        factory.setPort(5672);
        factory.setUsername("test");
        factory.setPassword("test");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
                    throws IOException {
                String message = new String(body, "UTF-8");
                System.out.println(" [x] Received '" + message + "'");
                String tipo[] = message.split(":");
                String params[] = tipo[1].split(",");
                if(tipo[0].equals("comentario")){
                    try {
                        Comentar(params[0], params[1]);
                        EnviarTabla();
                    } catch (Exception ex) {
                        Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }else{
                    if(params[0].equals("usuario") && params[1].equals("contra")){
                        try {
                            LoginCorrecto();
                            EnviarTabla();
                        } catch (Exception ex) {
                            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }else{
                        try {
                            LoginIncorrecto();
                        } catch (Exception ex) {
                            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        };
        channel.basicConsume(QUEUE_NAME, true, consumer);
    }
    
    public static String VerComentarios() {
        String coment="";
        try {
            Jedis jedis = new Jedis("localhost");
            Set<String> usuarios = jedis.keys("*");
            
            for(String usuario : usuarios){
                coment += usuario + ":";
                List<String> comentarios = jedis.lrange(usuario, 0, -1);
                
                for(String comentario: comentarios){
                coment += comentario;    
                }
            }

            

        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        return coment;
    }
    
    public static void Comentar(String usuario, String comentario) {

        try {
            Jedis jedis = new Jedis("localhost");
            jedis.rpush(usuario, comentario);
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }
    
    public static void LoginCorrecto() throws Exception{
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("35.237.249.51");
        factory.setPort(5672);
        factory.setUsername("test");
        factory.setPassword("test");
        Connection connection;
        connection = factory.newConnection();
        Channel channel = connection.createChannel();
        String message = "correcto";
        channel.basicPublish("", "respuestalogin", null, message.getBytes("UTF-8"));
        System.out.println(" [x] Sent " + message + "");
        channel.close();
        connection.close();
    }
    
    public static void EnviarTabla() throws Exception{
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("35.237.249.51");
        factory.setPort(5672);
        factory.setUsername("test");
        factory.setPassword("test");
        Connection connection;
        connection = factory.newConnection();
        Channel channel = connection.createChannel();
        String message = VerComentarios();
        channel.basicPublish("", "comentario", null, message.getBytes("UTF-8"));
        System.out.println(" [x] Sent " + message + "");
        channel.close();
        connection.close();
    }
    
    public static void LoginIncorrecto() throws Exception{
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("35.237.249.51");
        factory.setPort(5672);
        factory.setUsername("test");
        factory.setPassword("test");
        Connection connection;
        connection = factory.newConnection();
        Channel channel = connection.createChannel();
        String message = "incorrecto";
        channel.basicPublish("", "respuestalogin", null, message.getBytes("UTF-8"));
        System.out.println(" [x] Sent " + message + "");
        channel.close();
        connection.close();
    }

}
