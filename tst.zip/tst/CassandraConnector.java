/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionbd;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fab
 */
public class CassandraConnector {

    private Cluster cluster;

    private Session session;

    public static void main(String[] args) {
        CassandraConnector cc = new CassandraConnector();
        try {
            System.out.println(cc.Encriptar("1234"));
            //cc.conectar();
            cc.insertarUsuario("fabio", "4321", "Fabio", "DP");
            cc.Select("fab", "1234");

        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(CassandraConnector.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void conectar() {
        CassandraConnector client = new CassandraConnector();
        client.connect("127.0.0.1", 9142);
        this.session = client.getSession();

    }

    public void connect(String node, Integer port) {
        Cluster.Builder b = Cluster.builder().addContactPoint(node);
        if (port != null) {
            b.withPort(port);
        }
        cluster = b.build();

        session = cluster.connect();
    }

    public Session getSession() {
        return this.session;
    }

    public void close() {
        session.close();
        cluster.close();
    }

    public void insertarUsuario(String nombre_usuario, String password, String nombre, String apellido) {
        /*INSERT INTO sopes.usuarios
            VALUES (now(), 'fab','1234','Fabio','De Paz',toTimeStamp(now()));*/

        String sb;
        try {
            sb = "INSERT INTO sopes.usuarios (id, nombre_usuario , password , nombre , "
                    + "apellido , fecha_registro ) VALUES (now(), '" + nombre_usuario + "'"
                    + ", '" + Encriptar(password) + "'" + ", '" + nombre + "'" + ", '" + apellido + "'"
                    + ",toTimeStamp(now())" + ");";

            System.out.println(sb);
            //session.execute(sb);
        } catch (NoSuchAlgorithmException ex) {
            System.err.println(ex.getMessage());
        }

    }

    public void Select(String nombre_usuario, String password) {

        //select * from sopes.usuarios where nombre_usuario in ([nombre_usuario]) AND password =[password] ALLOW FILTERING ;
        String sb;
        try {
            sb = "SELECT * FROM sopes.usuarios "
                    + "WHERE nombre_usuario in ('" + nombre_usuario + "') AND password = '"
                    + Encriptar(password) + "' ALLOW FILTERING;";
            System.out.println(sb);
            //session.execute(sb);
        } catch (NoSuchAlgorithmException ex) {
            System.err.println(ex.getMessage());
        }

    }

    private String convertBytetoHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte byt : bytes) {
            result.append(Integer.toString((byt & 0xff) + 0x100, 16).substring(1));
        }
        return result.toString();
    }

    public String Encriptar(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(data.getBytes());
        return convertBytetoHex(md.digest());
    }
}
