/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionbd;

import redis.clients.jedis.Jedis;

/**
 *
 * @author fab
 */
public class CONEXIONBD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // TODO code application logic here
        try {
            Jedis jedis = new Jedis("localhost");
            jedis.set("foo", "bar");
            String value = jedis.get("foo");
            System.out.println(value);
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }

}
